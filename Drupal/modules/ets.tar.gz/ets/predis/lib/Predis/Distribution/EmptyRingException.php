<?php

namespace Predis\Distribution;

class EmptyRingException extends \Exception {
}
