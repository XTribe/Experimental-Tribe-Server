<?php

namespace Predis;

interface IReplyObject {
}
