<?php

namespace Predis\Commands;

class ListInsert extends Command {
    public function getId() {
        return 'LINSERT';
    }
}
