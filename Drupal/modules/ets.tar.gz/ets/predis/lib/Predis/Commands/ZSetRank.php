<?php

namespace Predis\Commands;

class ZSetRank extends Command {
    public function getId() {
        return 'ZRANK';
    }
}
