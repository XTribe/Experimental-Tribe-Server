<?php

namespace Predis\Commands;

class ListTrim extends Command {
    public function getId() {
        return 'LTRIM';
    }
}
