<?php

namespace Predis\Commands;

class ListRange extends Command {
    public function getId() {
        return 'LRANGE';
    }
}
