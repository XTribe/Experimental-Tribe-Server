<?php

namespace Predis\Commands;

class ListIndex extends Command {
    public function getId() {
        return 'LINDEX';
    }
}
