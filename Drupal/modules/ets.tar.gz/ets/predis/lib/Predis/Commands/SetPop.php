<?php

namespace Predis\Commands;

class SetPop  extends Command {
    public function getId() {
        return 'SPOP';
    }
}
