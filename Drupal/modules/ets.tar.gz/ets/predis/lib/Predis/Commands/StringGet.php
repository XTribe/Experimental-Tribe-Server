<?php

namespace Predis\Commands;

class StringGet extends Command {
    public function getId() {
        return 'GET';
    }
}
