<?php

namespace Predis\Commands;

class ListSet extends Command {
    public function getId() {
        return 'LSET';
    }
}
