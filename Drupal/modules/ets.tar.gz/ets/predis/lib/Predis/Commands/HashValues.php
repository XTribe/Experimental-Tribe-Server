<?php

namespace Predis\Commands;

class HashValues extends Command {
    public function getId() {
        return 'HVALS';
    }
}
