<?php

namespace Predis\Commands;

class StringSet extends Command {
    public function getId() {
        return 'SET';
    }
}
