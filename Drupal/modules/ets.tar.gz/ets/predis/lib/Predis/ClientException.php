<?php

namespace Predis;

class ClientException extends PredisException {
}
