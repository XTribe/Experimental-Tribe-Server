<?php

namespace Predis;

abstract class PredisException extends \Exception {
}
