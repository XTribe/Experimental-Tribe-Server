<?php

namespace Predis\Network;

use Predis\CommunicationException;

class ConnectionException extends CommunicationException {
}
