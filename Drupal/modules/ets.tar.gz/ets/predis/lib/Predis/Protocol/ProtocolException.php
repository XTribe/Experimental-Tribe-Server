<?php

namespace Predis\Protocol;

use Predis\CommunicationException;

class ProtocolException extends CommunicationException {
}
