(function ($) {

  Drupal.behaviors.ets_location = {
    
    attach: function (context) {
      
      var $updPos = $('#ets-upd-position');

      if ('geolocation' in navigator) {
      
        //{enableHighAccuracy:true});
        
        function updateLocation(position) {
          $updPos.html('Position: ' + position.coords.latitude.toFixed(6) + ", " + position.coords.longitude.toFixed(6) + " accuracy: " + position.coords.accuracy);
        }
        
        function positionError(error) {
          navigator.geolocation.clearWatch(watchId);
          disablePosition(error.message);
        }
        
        var watchId = navigator.geolocation.watchPosition(updateLocation, positionError);

        //navigator.geolocation.clearWatch(watchId);
      } else {
        disablePosition("unsupported web browser");
      }
     
      function disablePosition(reason) {
        var $radio = $('#edit-loc-type-2');
        if ($radio.is(':checked')) {
          $('#edit-loc-type-' + 3).attr('checked', true)
        }
        $radio.attr('disabled', true);
        $updPos.html("Not available: " + reason);
      }
      
    }
    
  };

})(jQuery);

