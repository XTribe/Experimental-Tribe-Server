(function ($) {

  // Adjust the overlay dimensions.
  Drupal.behaviors.ets_overlay = {
    
    attach: function (context) {
      
      $('table.field-ui-overview thead').remove();
      
      if (!$('body').hasClass('page-ets')) {
        return;
      }
      $('#overlay:not(.ets-adjusted)', context).each(function() {
        // adjust the overlay
        $(this).css({
          'width'     : '420px',
          'min-width' : '420px'
        });
          
        $('.add-or-remove-shortcuts', this).hide();  // hide "add short-cut" button
        $('#branding', this).hide();  // hide branding container
      }).addClass('ets-adjusted');
    }
    
  };

})(jQuery);