
(function ($) {

  // The cycle plugin must be initialized onload because to resize the
  // container the images have to be loaded
  $(window).load(function() {
    if (!$.fn.cycle) {
      return;
    }

    $(".field-name-field-screenshot .field-items").cycle({
      containerResize: 1,
      fit: 1,
      fx: 'scrollRight'
    }).css({"visibility": 'visible'});

    $(".field-name-field-screenshot .field-items a").attr('target', '_blank');

  });

/* Needed only for the fbconnect module
  Drupal.behaviors.ets_fix_facebook = {
    attach: function() {
      var $fblabel = $("label[for=fbconnect_button]");
      if ($fblabel.length == 0) {
        return;
      }
      $fblabel.parent().wrap("<li class='last' id='fbconnect-controls'></li>");
      $fblabel.hide();
      var $controls = $("#fbconnect-controls");
      $controls.appendTo($controls.next("ul"));
    }
  }
*/

  Drupal.behaviors.ets_experiment_form = {
    
    attach: function() {

      var $conds = $('#edit-act-conditions .fieldset-wrapper');

      $.get('/ets/conditions/load', {}, function(data) {
        $(data[1].data).appendTo($conds);
      });
      
      $conds.delegate(".ets-condition .rm-cond", "click", function(e) {
        if (confirm("Are you sure?")) {
          $(this).closest('div').remove();
        }
        e.preventDefault();
        return false;
      })
      
      
      $("#edit-fields option:contains('disabled')").attr('disabled', 'disabled').text(function() {
        return $(this).text().replace('disabled ', '');
      });
        
      $('#edit-add-condition').click(function(e) {
        
          var field = $('#edit-fields').val()
            , n     = $('.ets-condition').length
        
        if ('--' == field) {
          alert("Please select a user field name");
          return false;
        }
        
        $.get('/ets/conditions/new', {f: field, i: (n + 1)}, function(data) {

          $(data[1].data).appendTo($conds);
          
          Drupal.behaviors.autocomplete.attach($conds);
          
        });
        
        e.preventDefault();
        return false;
      });
    
    }
  }
})(jQuery);
