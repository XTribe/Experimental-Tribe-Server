<?php 
$html="";

function connetti($SQL){
	$conn = mysql_connect("localhost", "xtribe", "xtribe123"); 
	$db = mysql_select_db("xtribe",$conn);
	//mysql_set_charset("utf8");
	$risultato = mysql_query($SQL,$conn);
	if (!$risultato){
	 echo "Query non valida: " . mysql_error()."----".$SQL;
	}
	return($risultato); 
}

function getmicrotime(){
	list($usec,$sec) = explode(" ",microtime());
  	$micro=((float)$usec +(float)$sec);
  	return $micro;
}

// ------ MANAGERS MONITOR
/*$html .= '<div class="page-header"><h1>Managers Monitor</h1></div>';

$html .= "<div style='float:left; font-size:11px !important; line-height: 13px;'>Managers Monitor shows the current status of all games' managers. <br>
  <strong style='color:#8AAF45;'>Legend:</strong><br>
  - Game: Extended name of the game.<br>
  - Manager Uri: The current address of the game's own manager.<br>
  - Status: The status of manager represented by a green light if the manager is up and running, and a red one if it is not available for any reason.<br>
  - Response: The response time of the manager, in milliseconds.<br>
  </div><br><div style='float:right;'><input type='checkbox' id='realtime_php' value='1'>
<label for='realtime_php' onclick=''>Real-time</label><a class='btn btn-success' href='#' onclick=''>Update now</a></div><br><br>";
*/

$queryManagers="SELECT u.entity_id, u.field_mgr_uri_value, n.title
      FROM field_data_field_mgr_uri u, node n
      WHERE u.entity_id=n.nid
      ORDER By n.title ASC";
$rsManagers = connetti($queryManagers);

$html.="<table class='sticky-enabled tableheader-processed sticky-table'>
			<thead>
			<tr>
			<th>Game</th>
			<th>Manager Uri</th>
			<th>Status</th>
			<th>Response</th>
			</tr>
			</thead>
			<tbody>
		";
$odd_even="odd";

while ($valManagers=mysql_fetch_array($rsManagers)) {
  	$html.="<tr class='".$odd_even."'>";      
	if($odd_even=="odd") { $odd_even="even"; } else { $odd_even="odd"; } 

    // Get host and port separated from complete uri
    $uriParsed=parse_url(trim($valManagers['field_mgr_uri_value']));
    $managerHost=$uriParsed['host'];
    $managerPort=$uriParsed['port'];
    
    // Test if manager is alive
    // ip,port,system level error number,error message string, timeout (seconds)
    // Pay attention to the timeout! To work without delay it must be equal to the interval
    // between an update of the page and the other (defined in xtribeMonitorFunctions.js)

	$time_start = getmicrotime();
    $valid = @fsockopen($managerHost, $managerPort, $errno, $errstr, 2); 
    $time_end = getmicrotime();
    $time_response = $time_end - $time_start;

    if (!$valid) $status = '<img src="../sites/all/modules/ets/images/offline.png" height="35" width="35">';
    else $status = '<img src="../sites/all/modules/ets/images/online.png" height="35" width="35">';

	$html.="<td>".htmlentities($valManagers['title'])."</td>";
	$html.="<td>".$valManagers['field_mgr_uri_value']."</td>";
    $html.="<td>".$status."</td>";
    $html.="<td>".substr($time_response , 0, 12)."</td>";
	$html.="</tr>";
}
$html.="</tbody> </table>";

echo $html;

/*$starttime = microtime(true);
$endtime = microtime(true);
$duration = $endtime - $starttime;
$html.= "Delay: ".$duration;*/

?>






