(function ($) {

  // Adjust forms
  Drupal.behaviors.ets_form = {
    
    // Hide the admin overlay settings in user profile form
    attach: function (context) {
      $('#edit-overlay-control').hide();
    }
    
  };

})(jQuery);