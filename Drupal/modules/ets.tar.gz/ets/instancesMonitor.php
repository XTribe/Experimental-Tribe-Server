<?php 
$html="";
function connetti($SQL){
	$conn = mysql_connect("localhost", "xtribe", "xtribe123"); 
	$db = mysql_select_db("xtribe",$conn);
	//mysql_set_charset("utf8");
	$risultato = mysql_query($SQL,$conn);
	if (!$risultato){
	 echo "Query non valida: " . mysql_error()."----".$SQL;
	}
	return($risultato); 
}

// ------ INSTANCES MONITOR
$queryInstances="SELECT i.*, n.title
                        FROM ets_instances i, node n
			WHERE i.nid=n.nid
			AND i.inst_dropped IS NULL 
			AND i.inst_ended IS NULL
			AND i.inst_error IS NULL
			AND i.inst_hunged IS NULL
            ORDER By nid, instance_id ASC";
$rsInstances = connetti($queryInstances);

$nid=-1;
$odd_even="odd";

$html.= "<div style='font-size:11px !important; line-height: 13px;'></div>";
while($valInstances=mysql_fetch_array($rsInstances)){  
	$html.="<tr class='".$odd_even."'>";      
	if($odd_even=="odd") { $odd_even="even"; } else { $odd_even="odd"; } 
	          
	if($valInstances['inst_created'] != ''){ $date_created=date('d/m/Y H:i',$valInstances['inst_created']);
	}else{ $date_created=''; }
	if($valInstances['inst_started'] != ''){ $date_started=date('d/m/Y H:i',$valInstances['inst_started']);
	}else{ $date_started=''; }
	if($valInstances['inst_performed'] != ''){ $date_performed=date('d/m/Y H:i',$valInstances['inst_performed']); 
	}else{ $date_performed=''; }
	if($valInstances['inst_ended'] != ''){ $date_ended=date('d/m/Y H:i',$valInstances['inst_ended']);
	}else{ $date_ended=''; }
	if($valInstances['inst_dropped'] != ''){ $date_dropped=date('d/m/Y H:i',$valInstances['inst_dropped']);
	}else{ $date_dropped=''; }
	if($valInstances['inst_error'] != ''){ $date_error=date('d/m/Y H:i',$valInstances['inst_error']);
	}else{ $date_error=''; }
	if($valInstances['inst_hunged'] != ''){ $date_hunged=date('d/m/Y H:i',$valInstances['inst_hunged']);
	}else{ $date_hunged=''; }

	if($valInstances['nid'] != $nid || $nid==-1){


		$nid= $valInstances['nid'];
		$title= $valInstances['title'];
				
		if($nid!=-1){ $html.="</div> </tbody> </table>"; }		

		$html.='</div> </tbody> </table><a id="displayText" href="javascript:toggle('.$nid.');">Experiment: '.$title.' '.'</a><br><br>';
		//$html.='</div> </tbody> </table><a id="displayText" href="javascript:toggle('.$nid.');">Experiment: '.$title.' '.'<img src="../sites/all/modules/ets/images/hide_icon.jpg"></a><br><br>';
		
		$html.="<table class='sticky-enabled tableheader-processed sticky-table'>
			<thead>
			<tr>
			<th sort='asc' 0='Instance'>#</th>
			<th>User(s)</th>
			<th>Created</th>
			<th>Started</th>
			<th>Performed</th>
			<th>Ended</th>
			<th>Dropped</th>
			<th>Error</th>
			<th>Hunged</th>
			</tr>
			</thead>
			<tbody>
		";
	}
	$nid= $valInstances['nid'];
	$title= $valInstances['title'];

	$html.="<td>".$valInstances['instance_id']."</td>";
	$html.="<td>".$valInstances['uid']/*."<br>".$valInstances['guid']."</td>"*/;
	$html.="<td>".$date_created."</td>";
	$html.="<td>".$date_started."</td>";
	$html.="<td>".$date_performed."</td>";
	$html.="<td>".$date_ended."</td>";
	$html.="<td>".$date_dropped."</td>";
	$html.="<td>".$date_error."</td>";
	$html.="<td>".$date_hunged."</td>";

	$html.="</tr>";
}

if (mysql_num_rows($rsInstances)==0) {
	$html.= "No active instance available";
}

$html.="</div> </tbody> </table>";

echo $html;
?>






