
ETS.JoinShell = function() {
  
  // Lo utilizziamo per capire se è passato troppo tempo
  // in fase di join
  this.interval = null;
  
  this.position = null;
  
  this.timestamp = 0|(new Date().getTime() / 1000);
  
  this.channel = null;

  this.ids = null;
}

ETS.JoinShell.prototype = new ETS.Shell;

ETS.JoinShell.prototype.setChannel = function(channel) {
  this.channel = channel;
}

ETS.JoinShell.prototype.setIds = function(ids) {
  this.ids = ids;
}
  
ETS.JoinShell.prototype.setPosition= function(data) {
  this.position = data;
}

ETS.JoinShell.prototype.tick = function() {
  var secs = (0|(new Date().getTime() / 1000)) - this.timestamp;
  this.trigger('tick', secs);
}
  
ETS.JoinShell.prototype.shutdown = function(data) {
  this.channel.close();
  clearInterval(this.interval);
}

ETS.JoinShell.prototype.boot = function() {
  
  var js = this;
  
  this.channel.on('close', function() {
    // just wait a couple of seconds: it would be our end fault
    setTimeout(function() {
      js.trigger('disconnect')
    }, 2000);
  });

  this.channel.on('message', function(message) {

    switch (message.topic) {

      case 'accept':
        js.trigger('accept');
        break;

      case 'status':
        // Se non è un messaggio di errore resettiamo il countdown
        if (!message.params.exception) {
          js.timestamp = 0|(new Date().getTime() / 1000);
        }
        
        js.trigger('status', message)
        break;

      case 'start':
        /* Nei parametri c'è il instance Id (iId)*/
        js.trigger('start', message.params)
        break;
        
      case 'refuse':
        js.trigger('refuse', message.params.reason);
        break;

      case 'error':
        js.trigger('error', message.params);
        break;

      default:
        js.trigger('error', "Some strange message arrived (" + message.topic + ")");
        break;
    }
  });

  this.channel.on('open', function() {
    
    js.channel.send({
                      topic: 'join',
                      params: {
                        eId:  js.ids.eId,
                        uId:  js.ids.uId,
                        guid: js.ids.guid,
                        position: js.position
                      }
                    });
    js.interval = setInterval(function() {
      js.tick();
    }, 1000);
    js.trigger('connect')
  });

  this.channel.on('error', function(error) {
    js.trigger('error', error)
  });

  this.channel.open();
  
}
  
// CommonJS compatibility layer
if (typeof module != 'undefined') {
  module.exports = ETS.JoinShell;
}

