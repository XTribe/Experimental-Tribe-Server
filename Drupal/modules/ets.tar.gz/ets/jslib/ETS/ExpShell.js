
ETS.ExpShell = function() {
  this.expWindow = null;
  this.ids = null;
  this.wnd = (typeof window != 'undefined') ? window : null
  this.channel = null;
}

ETS.ExpShell.prototype = new ETS.Shell;

/* This is the experiment window or whatever respond to postMessage */
ETS.ExpShell.prototype.setExperimentWindow = function(expWindow) {
  this.expWindow = expWindow;
}

ETS.ExpShell.prototype.setChannel = function(channel) {
  this.channel = channel;
}
  
ETS.ExpShell.prototype.setWindow = function(wnd) {
  this.wnd = wnd;
}
  
ETS.ExpShell.prototype.setIds = function(ids) {
  this.ids = ids;
}
  
ETS.ExpShell.prototype.shutdown = function(data) {
  var ch = this.channel;
  ch.send({
    eId:    this.ids.eId,
    iId:    this.ids.iId,
    uId:    this.ids.uId,
    guid:   this.ids.guid,
    topic:  'over',
    params: data || null
  }, function() {
    // Se si chiude il canale, il over da MHS non arriva e l'evento on("over") non viene recepito
    // ch.close();
  });
}

ETS.ExpShell.prototype.boot = function() {

  var gs = this;

  this.channel.on('close', function() {
    var ch = this;
    // just wait a couple of seconds: it could be our end fault
    setTimeout(function() {
      if (ch.connected) {
        gs.expWindow.postMessage(JSON.stringify({topic: 'error', params: {error: 'Remote end disconnected'}}), "*")
      }
      gs.trigger('disconnect')
    }, 2000);
  });
  
  this.channel.on('error', function(error) {
    gs.trigger('error', error)
  });
  
  this.channel.on('open', function() {

    var ch = this;

    // Ci mettiamo in ascolto per i messaggi del gioco 
    // In realtà chiunque potrebbe spedirci messaggi. 
    // Verificare se origin può essere controllato (i giochi dovrebbero risiedere in exp.dominio...)
    ETS.Tools.addEvent(gs.wnd, 'message', function(event) {

      event = event || window.event;

      var message;
      try {
        message = JSON.parse(event.data);
      } catch(e) {}
      
      if (typeof message == 'undefined' || typeof message.topic == 'undefined') {
        return;
      }

      // Questi messaggi arrivano spediti dal Client.js, che li ha
      // ricevuti dal gioco tramite metodo sendMessage() o over
      switch (message.topic) {
        
        case 'forward':
          // Deliver message on channel for the manager
          ch.send({
            eId:    gs.ids.eId,
            iId:    gs.ids.iId,
            uId:    gs.ids.uId,
            guid:   gs.ids.guid,
            topic:  'forward',
            params: message.params
          });
          break;
          
        /* Il gioco è terminato */
        case 'over':
          gs.trigger('over', message.params)
          break;
          
        /* Il gioco è stato interrotto */
        case 'abort':
          gs.trigger('abort', message.params)
          break;

        /* A request to play again */
        case 'go-to':
          // Before going away, issue the topic (over or abort - abort is the default)
          gs.trigger((message.params.topic ? message.params.topic : 'abort'), function() {

            switch(message.params.location) {
              
              case 'join':
                window.location.href = ETS.Tools.themedUrl("/ets/exp-join/" + gs.ids.eId);
                break;

              case 'home':
                window.location.href = ETS.Tools.themedUrl("/");
                break;

              case 'description':
                window.location.href = ETS.Tools.themedUrl("/node/" + gs.ids.eId);
                break;

              default:
                window.location.href = ETS.Tools.themedUrl("/");
                break;
            }

          });
          break;

        /* A request for loading options */
        case 'options-load':
          jQuery.getJSON("/ets/services/options-load/" + gs.ids.eId + "/" + encodeURIComponent(message.params.namespace), function(data) {
            gs.expWindow.postMessage(JSON.stringify({topic: 'options-load', params: {options: data}}), "*");
          });
          break;

        /* A request for saving options */
        case 'options-save':
          jQuery.post("/ets/services/options-save/" + gs.ids.eId + "/" + encodeURIComponent(message.params.namespace), {options: JSON.stringify(message.params.options)}, function(data) {
            gs.expWindow.postMessage(JSON.stringify({topic: 'options-save'}), "*");
          });
          break;
          
        default:
          break;
        
      }
    });

    ch.send({
      eId:   gs.ids.eId,
      iId:   gs.ids.iId,
      uId:   gs.ids.uId,
      guid:  gs.ids.guid,
      topic: 'ready'
    });
    
    // Siamo pronti: diciamo al gioco che può iniziare
    gs.expWindow.postMessage(JSON.stringify({topic: 'start'}), "*");
    
  });
  
  // Listen to channel for incoming messages from manager
  this.channel.on('message', function(message) {

    switch (message.topic) {
      case 'error':
        gs.expWindow.postMessage(JSON.stringify({topic: 'error', params: message.params}), "*")
        break;
        
      case 'forward':
        gs.expWindow.postMessage(JSON.stringify({topic: 'deliver', params: message.params}), "*")
        break;
        
      case 'over':
        gs.expWindow.postMessage(JSON.stringify({topic: 'over', params: message.params}), "*")

        // The AJAX request here is tricky: we request the data for the experiment, which can or cannot
        // has been updated (the TLS has been run before us, but it's running elsewhere so these calls
        // are asynchronous). The instance-scores method will wait for some time waiting for the data
        // to be available, but there is still a chance that those data will never come
        if ('postMessage' in window) {
          jQuery.getJSON("/ets/services/instance-scores", {eId: gs.ids.eId, uId: gs.ids.uId, iId: gs.ids.iId}, function(data) {
            window.parent.postMessage("ETS_Scores::" + JSON.stringify(data), "*");
          });
        }

        // Chiudiamo il canale
        this.close();
        break;

      case 'abort':
        gs.expWindow.postMessage(JSON.stringify({topic: 'abort', params: message.params}), "*")
        // Non chiudiamo il canale perché il client potrebbe voler continuare
        gs.trigger('abort')
        break;
        
      default:
        // FIXME gestione errore
        alert("Unrecognized message topic received from MHS: " + message.topic);
        break;
    }
  });

  this.channel.open();
}

// CommonJS compatibility layer
if (typeof module != 'undefined') {
  module.exports = ETS.ExpShell;
}
