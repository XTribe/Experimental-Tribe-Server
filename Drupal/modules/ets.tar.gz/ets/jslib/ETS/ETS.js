// Useless in 0.7
// WEB_SOCKET_SWF_LOCATION = '/sites/all/modules/ets/jslib/WebSocketMain.swf';

var ETS = (function() {
    
  return {
    
    Tools: {
      
      // A random number
      rnd: function(max) {
        return Math.ceil(Math.random(1) * max)
      }
      
      ,
      
      // Zero Fill
      zf: function(n, w) { 
        w -= n.toString().length;
        if (w > 0) {
          return new Array( w + (/\./.test( n ) ? 2 : 1) ).join( '0' ) + n;
        }
        return n;
      }
      
      ,
      
      // Simple cross browser event handlers (used also in Client.js)
      // See also http://javascriptrules.com/2009/07/22/cross-browser-event-listener-with-design-patterns/
      addEvent: function (el, ev, fn) {
        if (el.addEventListener) {
          el.addEventListener(ev, fn, false);
        } else if (el.attachEvent) {
          el.attachEvent('on' + ev, fn);
        } else {
          el['on' + ev] = fn;
        }
      },

      // Edit an url adding the theme parameter when necessary
      themedUrl: function(url) {
        var qs = window.location.href.split('?')[1];
        if (qs) {
          var parts = qs.split("&");
          for (var i=0; i < parts.length; i++) {
            var value = parts[i].split("=");
            if (value[0] == 'theme') {
              return url + (url.indexOf('?') > -1 ? '&' : '?') + "theme=" + value[1];
            }
          }
        }
        return url;
      }

    },

    // Drupal Helpers
    Drupal: {

      // From bootstrap.inc
      WATCHDOG_EMERGENCY: 0,
      WATCHDOG_ALERT:     1,
      WATCHDOG_CRITICAL:  2,
      WATCHDOG_ERROR:     3,
      WATCHDOG_WARNING:   4,
      WATCHDOG_NOTICE:    5,
      WATCHDOG_INFO:      6,
      WATCHDOG_DEBUG:     7,

      watchdog: function(type, message, severity) {

        jQuery.post("/ets/services/watchdog", {
          type: type,
          message: message,
          severity: severity || ETS.Drupal.WATCHDOG_NOTICE
        });

      }

    },
    
    Channel: function(host, port, service) {
      
      var to
        , connected = false;

      this.ets_key = null;

      this.socket;

      this.connected = false;
      
      this.eventCbs = {};
        
      this.on = function(event, cb) {
        if (event != 'close' &&
            event != 'open'  &&
            event != 'error' &&
            event != 'message') {
          window.alert("Cannot listen on the unknown event " + event);
          return;
        }
        
        this.eventCbs[event] = cb;
      }

      this.trigger = function(event, param) {
        this.eventCbs[event] && this.eventCbs[event].apply(this, [param]);
      }

      this.open = function() {

        var ch = this;
 
        this.socket = new SockJS("http://" + host + ":" + port + "/" + service);

        this.socket.onopen = function() {
          clearTimeout(to);
          ch.connected = true;
          ch.trigger('open')
       };
        
        this.socket.onclose = function() {
          ch.trigger('close')
        };

        this.socket.onerror = function(e) {
          var msg = e;
          if (JSON) msg = JSON.stringify(e);
          ch.trigger('error', "Unspecified error - " + msg)
        };

        this.socket.onmessage = function(data) {
          try {
            data = JSON.parse(data.data);
          } catch(e) {
            data = {};
          }
          ch.trigger('message', data);
        };
        
        to = setTimeout(function() {
          ch.trigger('error', "Timeout occurred")
        }, 10000);
      }
      
      this.close = function() {
        // Questo dato serve per capire se la connessione è stata
        // interrotta volutamente o meno
        this.socket.close();
        if (this.connected) {
          this.connected = false;
        }
      }

      this.setETSKey = function(key) {
        this.ets_key = key;
      }

      this.getETSKey = function() {
        return this.ets_key ?  this.ets_key : (typeof Drupal != 'undefined' ? Drupal.settings.ets_key : "ets demo key");
      }

      this.send = function(message, cb) {
        if (this.connected) {
          this.socket.send(JSON.stringify(message));
          cb && cb();
        }
      }
    }
  }

})();

ETS.Shell = function() {
  this.eventCbs = {};
  this.observeCb = null;
}

ETS.Shell.prototype.observe = function(cb) {
  this.observeCb = cb;
}

ETS.Shell.prototype.on = function(event, cb) {
  this.eventCbs[event] = cb;
}

ETS.Shell.prototype.trigger = function(event, param) {
  if ('function' == typeof this.observeCb) {
    this.observeCb.apply(this, [event, param])
  }
  
  if ('function' == typeof this.eventCbs[event]) {
    this.eventCbs[event].apply(this, [param]);
  }
}

// CommonJS compatibility layer
if (typeof module != 'undefined') {
  module.exports = ETS;
}
