
;(function(window, $, undefined) {

  var paused = false;
  var $el;
  var $c;
  var $h;

  var ts = function() {
    var d = new Date();
    var time = [pad(d.getHours()),
                pad(d.getMinutes()),
                pad(d.getSeconds())].join(':');
    return [time].join(' ');
  
    function pad(n) {
      return n < 10 ? '0' + n.toString(10) : n.toString(10);
    }
  }

  var tracer = {

    init: function(m) {

      $('body').append('<div id="tracer"><div class="h"><a href="#">PAUSE</a></div><div class="z"><div class="c"/></div></div>');

      $el = $('#tracer');
      $c = $el.find('.c');
      $h = $el.find('.h');

      $h.find('a').on("click", $.proxy(function() {
        paused ? this.resume() : this.pause()
        paused ? $h.find('a').text('RESUME') : $h.find('a').text('PAUSE')
        return false;
      }, this));

      if (m) {
        this.write(m)
      }

      paused = false;
    },

    write: function(m) {

      if (paused) {
        return;
      }
      $c.append("<p>" + ts() + " " +  m + "</p>")
      $el.find('.z').scrollTop($c.get(0).scrollHeight);
    },

    pause: function() {
      this.write("&lt;paused&gt;");
      paused = true;
    },

    resume: function() {
      paused = false;
      write("&lt;resumed&gt;");
    }
  }

  $(function() {
    tracer.init("Tracer initialized");  
  });

  window.ETS = window.ETS || {};
  
  window.ETS.Tracer = tracer;

})(this, jQuery);
