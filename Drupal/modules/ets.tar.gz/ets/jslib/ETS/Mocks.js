
ETS.Mocks = ETS.Mocks || {};

ETS.Mocks.MessageReceiver = function() {

  this.messages = [];
};

ETS.Mocks.MessageReceiver.prototype.on = function(m, cb) {
  this.messages[m] = cb;
};

ETS.Mocks.MessageReceiver.prototype.manageMessage = function(message, params) {
  if (typeof this.messages[message] == 'function') {
    this.messages[message].call(this, params);
  }
};

ETS.Mocks.System = function() {

  ETS.Tools.addEvent(window, 'message', function(event) {

    event = event || window.event;
    
    var data = JSON.parse(event.data);

    if (data.recipient != 'system') {
      return;
    }

    this.manageMessage(data.params.topic, data.params.params);

  });

  setTimeout(function() {
    window.postMessage(JSON.stringify({sender: 'system', topic: 'start'}), "*");  
  }, 1000);

};

ETS.Mocks.System.prototype = new ETS.Mocks.MessageReceiver();

// Sends a message to the client
ETS.Mocks.System.prototype.send = function(topic, data) {
  window.postMessage(JSON.stringify({sender: 'system', topic: topic, params: data}), "*");  
};

ETS.Mocks.Manager = function() {

  ETS.Tools.addEvent(window, 'message', (function(event) {

    event = event || window.event;
    
    var data = JSON.parse(event.data);

    if (data.recipient != 'manager') {
      return;
    }

    this.manageMessage(data.params.topic, data.params.params);

  }).bind(this));

};

ETS.Mocks.Manager.prototype = new ETS.Mocks.MessageReceiver();

// Sends a message to the client
ETS.Mocks.Manager.prototype.send = function(topic, data) {
  window.postMessage(JSON.stringify({sender: 'manager', topic: 'deliver', params: { topic: topic, params: data}}), "*");  
};

if (!Function.prototype.bind) {
  Function.prototype.bind = function (oThis) {
    if (typeof this !== "function") {
      // closest thing possible to the ECMAScript 5 internal IsCallable function
      throw new TypeError("Function.prototype.bind - what is trying to be bound is not callable");
    }
 
    var aArgs = Array.prototype.slice.call(arguments, 1), 
        fToBind = this, 
        fNOP = function () {},
        fBound = function () {
          return fToBind.apply(this instanceof fNOP && oThis
                                 ? this
                                 : oThis,
                               aArgs.concat(Array.prototype.slice.call(arguments)));
        };
 
    fNOP.prototype = this.prototype;
    fBound.prototype = new fNOP();
 
    return fBound;
  };
}
