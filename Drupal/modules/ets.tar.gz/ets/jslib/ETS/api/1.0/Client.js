
var ETS = ETS || {}

ETS.Client = function(wnd) {

  this.source = null
  
  this.listener = null
  
  this.callbacks = {
    
    "receive": {
      "system":  null,
      "manager": null
    },
    
    "goto": null,
    
    "options-save": null,
    
    "options-load": null
    
  }
  
  this.outbox = []

  var client = this;

  this.wnd = (typeof window != 'undefined') ? window : wnd;
    
  // Event listener sulla window del gioco per i messaggi
  // che arrivano dalla expShell (START, DELIVER, ERROR, URL)
  
  addEvent(this.wnd, 'message', function(event) {

    event = event || window.event;
    var data = event.data;
    try {
      var message = JSON.parse(data);
    } catch(e) {
      return;
    }

    if (typeof message == 'undefined' || typeof message.topic == 'undefined') {
        return;
    }

    // Do not listen to messages originating from... ourself
    // The mock manager could send messages
    if (typeof ETS_EXP_DATA == "undefined" && window === client.source && message.sender !== 'manager') {
      return;
    }

    if (!client.source) {
      client.source = event.source;
      // Deliver queued messages
      for (var i=0; i < client.outbox.length; i++) {
        if (client.outbox[i].recipient != 'internal') {
          client.send(client.outbox[i].recipient, client.outbox[i].message)
        } else {
          client.source.postMessage(JSON.stringify(client.outbox[i].message), "*");
        }
      }
      client.outbox = []
    }

    var sender;
    
    switch (message.topic) {
      
      case 'deliver':
        sender = 'manager';
        message.topic  = message.params.topic;
        message.params = message.params.params;
        if (client.callbacks.receive[sender]) {
          client.callbacks.receive[sender].apply(client, [message, sender]);
        }
        break;
      
      case 'options-save':
        //console.log("CLIENT - event option-save");
        if (client.callbacks["options-save"]) {
            client.callbacks["options-save"].apply(client);       
        }
        break;
      
      case 'options-load':
        //console.log("CLIENT - event option-load - option ");
        if (client.callbacks["options-load"]) {
          //console.log(message.params.options);
          if (typeof message.params.options == 'undefined') {
            return;
          }else{
            client.callbacks["options-load"].apply(client, [message.params.options]);
          }
  
        }
        break;
      
      default:
        sender = 'system';
        if (client.callbacks.receive[sender]) {
          client.callbacks.receive[sender].apply(client, [message, sender]);
        }
        break;      
      
    }

  });
  // Also used in ETS.js
  function addEvent(el, ev, fn) {
    if (el.addEventListener) {
      el.addEventListener(ev, fn, false);
    } else if (el.attachEvent) {
      el.attachEvent('on' + ev, fn);
    } else {
      el['on' + ev] = fn;
    }
  }
  
}

/* Parameters order are quite smart:
 * () No parameters, debug
 * (sender) debug for the sender ('system' or 'manager')
 * (cb) the sender will be passed as the first argument to the callback,
 *      message as the second one
 */
ETS.Client.prototype.receive = function(sender, cb) {
  //console.log("RECEIVE MESSAGE from |"+sender+"| cb "+cb);

  // (callback)
  if ('function' == typeof sender) {
    this.callbacks.receive['system'] = this.callbacks.receive['manager'] = sender;
    return
  }

  // (void)
  if ('undefined' == typeof sender) {
    this.callbacks.receive['system'] = this.callbacks.receive['manager'] = dummyReceive
    return
  }
  
  if ('system' != sender && 'manager' != sender) {
    window.alert("Cannot receive messages from the unknown sender \"" + sender + "\"");
    return;
  }
  
  // (sender, callback)
  this.callbacks.receive[sender] = cb || dummyReceive;
  
  function dummyReceive(message, sender) {
    if (window.hasOwnProperty('console')) {
      console.log("From " + sender)
      console.log(message)
    }
  }
}

// Accepts messages in the forms:
// send('system', 'topic', params) and send('system', {topic: 'topic', params: params})
ETS.Client.prototype.send = function(recipient, message, params) {

  //console.log("SENDING MESSAGE |"+message+"| to |"+recipient+"| with params |"+params);
  if ('system' != recipient && 'manager' != recipient) {
    window.alert("Cannot send a message to an unknown recipient");
    return;
  }

  switch (typeof message) {
    
    case 'undefined':
      window.alert("Cannot send a message without a topic");
      return;

    case 'string':
      message = {
        topic: message,
        params: params || null
      }
      
      break;
    
    case 'object':
      message = {
        topic: message.topic,
        params: message.params || null
      }
      break;
    
    default:
      window.alert("Unsupported message format");
      return;
  }

  // We try to make things work even if someone sends message BEFORE they have
  // received the START message

  // Alert on chrome doesn't work at once, due to cache. To debug use firefox instead
  // window.alert("SEND recipient "+recipient+" topic: "+message.topic+" message:"+JSON.stringify(message)+" source: "+this.source); 
  if (!this.source) {
    this.outbox.push({recipient: recipient, message: message})
  } else {
    if ('system' == recipient) {
      this.source.postMessage(JSON.stringify({recipient: recipient, topic: message.topic, params: message.params}), "*");
    } else {
      this.source.postMessage(JSON.stringify({recipient: recipient, topic: 'forward', params: message}), "*");
    }
  }
}

/*
 * Set window.location.href back to the experiment join page
 */
ETS.Client.prototype.goToJoin = function(topic) {
  this.goTo('join', topic);
}

/*
 * Set window.location.href back to the server home
 */
ETS.Client.prototype.goToHome = function(topic) {
  this.goTo('home', topic);
}

/*
 * Set window.location.href back to the experiment description page
 */
ETS.Client.prototype.goToDescription = function(topic) {
  this.goTo('description', topic);
}

ETS.Client.prototype.goTo = function(location, topic) {
  topic = topic || 'abort';
  this._internalSendOrQueue({topic: "go-to", params: {'location': location, 'topic': topic}});
}

/*
 * Saves the passed in options to Drupal database
 */
ETS.Client.prototype.optionsSave = function(namespace, options, cb) {
  //console.log("-- Client -- Option Save");
  //console.log("-- Client -- save cb BEF: "+cb+" ----- thisCall: "+this.callbacks["options-save"]);
  if ('function' == typeof cb) {
    this.callbacks["options-save"] = cb;
  }
  this._internalSendOrQueue({topic: "options-save", params: {namespace: namespace, options: options}})
}

/*
 * Retrieve the passed in options to Drupal database
 */
ETS.Client.prototype.optionsLoad = function(namespace, cb) {
  //console.log("-- Client -- Option Load");
  if ('function' == typeof cb) {
    this.callbacks["options-load"] = cb;
    this._internalSendOrQueue({topic: "options-load", params: {namespace: namespace}})
    //console.log("-- Client -- Option Load INSIDE")
  } else {
    window.alert("The second parameter of optionsLoad must be a function")
  }
  //console.log("-- Client -- load cb AFT: "+cb+" ----- thisCall: "+this.callbacks["options-load"]);
}

// Helper to send (or queue) a message to the expShell ('internal' recipient)
ETS.Client.prototype._internalSendOrQueue = function(message) {
  if (!this.source) {
    this.outbox.push({recipient: 'internal', message: message})
  } else {
    /*console.log("CLIENT -- MESSAGE ")
    console.log(message);
    console.log("CLIENT -- SOURCE ")
    console.log(this.source.myETSClient);*/

    this.source.postMessage(JSON.stringify(message), "*");
  }
}

ETS.Client.prototype.setWindow = function(wnd) {
  this.wnd = wnd;
}

// CommonJS compatibility layer
if (typeof module != 'undefined') {
  module.exports = ETS.Client;
}

