(function($) {

$(document).ready(function(){

	 // This is used by the page Xtribe Monitor. The monitor shows real-time data about instances and managers
	 // so it needs to be updated every X seconds to be coherent with live happenings.
	 setInterval(function(){ // every x seconds
	 //window.setTimeout(function(){  // one time after x seconds (useful for debug)
		$('.substitute').load('../sites/all/modules/ets/instancesMonitor.php');
	 }, 1000);

});

})(jQuery);

// show/hide the div called "toggleText_"+row_nid
function toggle(row_nid) {
	var ele = document.getElementById("toggleText_"+row_nid);
	if(ele.style.display == "block") {
    		ele.style.display = "none";
  	}
	else {
		ele.style.display = "block";
	}
} 
