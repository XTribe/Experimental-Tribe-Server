

;(function($) {

  var channel = new ETS.Channel(Drupal.settings.ets.mon_host, Drupal.settings.ets.mon_port)
    , $status = $('#monitor-status')
    , html;

  channel.on('message', function(message) {

    $status.addClass('on');

    var $target = $('#' + message.h.topic + "-" + message.h.service + " .body");
    
    if ('log' == message.h.topic) {
      $target.append("<p>" + message.b + "</p>");
      $target.scrollTop($target.get(0).scrollHeight);
    } 
    
    if ('stats' == message.h.topic) {
      html = "<span class='timestamp'>Updated @ " + getTimestamp(message.h.ts) + "</span>";
      for (stat in message.b) {
        html += "<p><b>" + message.b[stat].label + ":</b> " + message.b[stat].value + "</p>"
      }
      $target.html(html);
    }
    
  });

  channel.on('open', function(error) {
    $status.addClass('on');
  });
  
  channel.on('error', function(error) {
    $status.addClass('off');
  });
    
  channel.on('close', function(error) {
    $status.addClass('off');
  });
    
  channel.open();
    
  function getTimestamp(ts) {
    var ct = new Date(ts * 1000);
    return zf(ct.getHours(),2) + ":" + zf(ct.getMinutes(),2) + ":" + zf(ct.getSeconds(),2);
    
  }
  
  function zf(n, w) { 
    w -= n.toString().length;
    if (w > 0) {
      return new Array( w + (/\./.test( n ) ? 2 : 1) ).join( '0' ) + n;
    }
    return n;
  }
  
  
})(jQuery);

