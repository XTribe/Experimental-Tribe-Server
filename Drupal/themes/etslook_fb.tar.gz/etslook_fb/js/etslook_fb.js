!function( $ ) {

  $(function () {

    // Adds the current theme to all the view-created links
    var href;
    $("#main a").each(function(idx, el) {
      href = $(el).attr('href');
      if (!href) {
        return;
      }
      href += (href.match(/\?/) ? '&' : '?') + "theme=etslook_fb";
      $(el).attr("href", href);
    });

    $('.tabs.primary').removeClass('primary').addClass('nav nav-tabs');

  });
  
}( window.jQuery17 );
