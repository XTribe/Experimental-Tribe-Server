!function( $ ) {

  $(function () {

    var h =$(".front #block-views-latest-games-block-1 > h3, #block-block-1 h3");

    $.each(h, splitAndPaint);
    
    function splitAndPaint(i,el) {
      var w, t, el = $(el);

      w = el.addClass('splitted').text().split(' ');

      t = $.map(w, function(el, i) {
        return "<span class=\"" + (i%2 ? 'odd' : 'even') + "\">" + el + "</span>";
      })
      
      el.html(t.join(' '))

    }



  })
  
}( window.jQuery17 )
