<?php

include_once(dirname(__FILE__) . '/includes/etslook.inc');

function etslook_form_system_theme_settings_alter(&$form, &$form_state) {
  $form['etslook_settings'] = array(
    '#type' => 'fieldset',
    '#title' => t('Etslook Settings'),
    '#collapsible' => TRUE,
    '#collapsed' => FALSE,
    '#weight' => -1
  );
  $form['etslook_settings']['etslook_css_files'] = array(
    '#type' => 'textarea',
    '#title' => t('CSS includes'),
    '#default_value' => etslook_theme_get_setting('etslook_css_files'),
    '#description' => t('Enter the path and filename, relative to Drupal root, where the CSS file is located, seperated by an new line.'),
  );
  $form['etslook_settings']['etslook_js_files'] = array(
    '#type' => 'textarea',
    '#title' => t('JS includes'),
    '#default_value' => etslook_theme_get_setting('etslook_js_files'),
    '#description' => t('Enter the path and filename, relative to Drupal root, where the JavaScript file is located, seperated by an new line.'),
  );
}

