<?php
   $server_name = ($_SERVER['SERVER_NAME']);
   $server_uri =($_SERVER['REQUEST_URI']); 
   if($server_name=='www.kreyon.net' && $server_uri=='/' ){
	   echo "<script language=\"javascript\">window.location = \"http://www.kreyon.net/kreyonDay/\"; </script>";
   }
   if($server_name=='www.kreyon.net' && $server_uri=='/node' ){
	   echo "<script language=\"javascript\">window.location = \"http://www.kreyon.net/kreyonDay/\"; </script>";
   }

   //echo('nETS:'.$server_name.' ');
   //echo('uETS:'.$server_uri);
 ?>
   <div class="navbar">
	  <div class="navbar-inner">
	    <div class="container">
		    <div class="row">
		    <div class="span11">
		    <?php if ($_SERVER['SERVER_NAME']=='141.108.5.30'){ ?>
		    	<img src="/sites/all/themes/etslook/internal-develop-ribbon.png" id="beta">
		    <?php }else{ // beta, we do not need it anymore ?>
		        <!-- <img src="/sites/all/themes/etslook/beta-ribbon.png" id="beta"> -->
		    <?php } ?>
					<a class="brand" href="/">
					  <?php if ($logo): ?>
						<img src="<?php print $logo; ?>" alt="<?php print t('Home'); ?>" />
					  <?php endif; ?>
					  
					  <?php if ($site_name): ?>
						<span id="site-name"><?php print $site_name; ?></span>
					  <?php endif; ?>	
					</a>
<?php /*		  
		  <div class="nav-collapse">
			<?php if ($main_menu ): ?>
			  <?php print theme('links__system_main_menu', array('links' => $main_menu, 'attributes' => array('id' => 'main-menu', 'class' => array('nav')))); ?>
			<?php endif; ?>
		  </div>
		  
		  <?php if ($secondary_menu): ?>
			<?php print theme('links__system_main_menu', array('links' => $secondary_menu, 'attributes' => array('id' => 'secondary-menu', 'class' => array('nav', 'secondary-nav', 'pull-right')))); ?>
		  <?php endif; ?>
		  
		  <div class="pull-right">
			<?php if ($search): print render($search); endif; ?>
		  </div>
*/ ?>		  
		  		<?php print render($page['header']); ?>
		    </div>
		    </div>
	    </div>
	  </div>
  </div>
  
  <div id="main" class="container">
		<div class="row">

		  <?php if ($page['highlight']): ?>
			<div class="highlight">
			  <?php print render($page['highlight']); ?>
			</div>
		  <?php endif; ?>
			
			<?php if ($breadcrumb): ?>
			  <?php /* print $breadcrumb; */ ?>
			<?php endif; ?>
			 
			<?php if ($tabs && $tabs['#primary']): ?>
			  <?php /* print render($tabs); */ ?>
			<?php endif; ?>
		
		  <?php if ($page['sidebar_first']): ?>
			<?php print render($page['sidebar_first']); ?>
		  <?php endif; ?>	  
		  
		  <div class="<?php print _etslook_content_span($columns); ?>">
			<?php print $messages; ?>
			<?php if ($title): ?>
			<div class="page-header">
			  <h1><?php print $title; ?></h1>
			</div>
			<?php endif; ?>
			
			<?php if ($tabs && $tabs['#primary']): ?>
			  <?php print render($tabs); ?>
			<?php endif; ?>

			<?php print render($page['content']); ?>

		  </div>
		  
		  <?php if ($page['sidebar_second']): ?>
			<?php print render($page['sidebar_second']); ?>
		  <?php endif; ?>
		  
		  <footer class="footer span11">
			<?php print render($page['footer']); ?>
		  </footer>
		</div>
  </div>
