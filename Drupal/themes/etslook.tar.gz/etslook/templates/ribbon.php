<?php
//echo '<img src="/sites/all/themes/etslook/ribbon-eXtribe.png" id="beta">';
?>