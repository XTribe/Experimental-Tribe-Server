<?php
   $server_name = ($_SERVER['SERVER_NAME']);
   $server_uri =($_SERVER['REQUEST_URI']); 

   if($server_name=='doc.xtribe.eu'){
   echo "<script language=\"javascript\">window.location = \"http://www.xtribe.eu/node/64\"; </script>";
   }
   if($server_name=='kreyon.net' && $server_uri=='/' ){
   echo "<script language=\"javascript\">window.location = \"http://www.kreyon.net/kreyonC/l.php?l=en\"; </script>";
   }
   if($server_name=='www.kreyon.net' && $server_uri=='/' ){
	 echo "<script language=\"javascript\">window.location = \"http://www.kreyon.net/kreyonC/l.php?l=en\"; </script>";
   }
   if($server_name=='www.kreyon.net' && $server_uri=='/node' ){
	 echo "<script language=\"javascript\">window.location = \"http://www.kreyon.net/kreyonC/l.php?l=en\"; </script>";
   }
   if($server_name=='www.xtribe.eu' && $server_uri=='/kreyon/' ){
	 echo "<script language=\"javascript\">window.location = \"http://www.kreyon.net/kreyonC/l.php?l=en\"; </script>";
   }

   //echo('nETS:'.$server_name.' ');
   //echo('uETS:'.$server_uri);
   //echo('sETS:'.$_SERVER);
 ?>
   <div class="navbar">
	  <div class="navbar-inner">
	    <div class="container">
		    <div class="row">
		    <div class="span11">
		    <div class="block-locale x-language-mobile">
				<?php
					$block = module_invoke('locale', 'block_view', 'language');
			   		print $block['content'];
				?>
			</div>	
		    <?php 
		    	include 'ribbon.php';
				/*$host_x = $_SERVER['SERVER_NAME']; 
				switch ($host_x) {
					// Infodyn - Extribe.eu
					case '141.108.5.20':
						echo '<img src="/sites/all/themes/etslook/ribbon-eXtribe.png" id="beta">';
					break;
					case 'www.extribe.eu':
						echo '<img src="/sites/all/themes/etslook/ribbon-eXtribe.png" id="beta">';
					break;
					case 'extribe.eu':
						echo '<img src="/sites/all/themes/etslook/ribbon-eXtribe.png" id="beta">';
					break;

					// Zinfandel - Internal Develop
					case '141.108.5.30':
						echo '<img src="/sites/all/themes/etslook/ribbon-internalDevelop.png" id="beta">';
					break;
					case 'zinfandel.phys.uniroma1.it':
						echo '<img src="/sites/all/themes/etslook/ribbon-internalDevelop.png" id="beta">';
					break;

					// Lab - Develop
					case '92.222.177.11':
						echo '<img src="/sites/all/themes/etslook/ribbon-develop.png" id="beta">';
					break;	
					case 'lab.xtribe.eu':
						echo '<img src="/sites/all/themes/etslook/ribbon-develop.png" id="beta">';
					break;	
					case 'www.lab.xtribe.eu':
						echo '<img src="/sites/all/themes/etslook/ribbon-develop.png" id="beta">';
					break;

					default:
					break;
				}*/
				
				?>
					<a class="brand" href="/">
					  <?php if ($logo): ?>
						<img src="<?php print $logo; ?>" alt="<?php print t('Home'); ?>" />
					  <?php endif; ?>
					  
					  <?php if ($site_name): ?>
						<span id="site-name"><?php print $site_name; ?></span>
					  <?php endif; ?>	
					</a>
<?php /*		  
		  <div class="nav-collapse">
			<?php if ($main_menu ): ?>
			  <?php print theme('links__system_main_menu', array('links' => $main_menu, 'attributes' => array('id' => 'main-menu', 'class' => array('nav')))); ?>
			<?php endif; ?>
		  </div>
		  
		  <?php if ($secondary_menu): ?>
			<?php print theme('links__system_main_menu', array('links' => $secondary_menu, 'attributes' => array('id' => 'secondary-menu', 'class' => array('nav', 'secondary-nav', 'pull-right')))); ?>
		  <?php endif; ?>
		  
		  <div class="pull-right">
			<?php if ($search): print render($search); endif; ?>
		  </div>
*/ ?>		  
		  		<?php print render($page['header']); ?>
		    </div>
		    </div>
	    </div>
	  </div>
  </div>
  
  <div id="main" class="container">
		<div class="row">

		  <?php if ($page['highlight']): ?>
			<div class="highlight">
			  <?php print render($page['highlight']); ?>
			</div>
		  <?php endif; ?>
			
			<?php if ($breadcrumb): ?>
			  <?php /* print $breadcrumb; */ ?>
			<?php endif; ?>
			 
			<?php if ($tabs && $tabs['#primary']): ?>
			  <?php /* print render($tabs); */ ?>
			<?php endif; ?>
		
		  <?php if ($page['sidebar_first']): ?>
			<?php print render($page['sidebar_first']); ?>
		  <?php endif; ?>	  
		  
		  <div class="<?php print _etslook_content_span($columns); ?>">
			<?php print $messages; ?>
			<?php if ($title): ?>
			<div class="page-header">
			  <h1><?php print $title; ?></h1>
			</div>
			<?php endif; ?>
			
			<?php if ($tabs && $tabs['#primary']): ?>
			  <?php print render($tabs); ?>
			<?php endif; ?>

			<?php print render($page['content']); ?>

		  </div>
		  
		  <?php if ($page['sidebar_second']): ?>
			<?php print render($page['sidebar_second']); ?>
		  <?php endif; ?>
		  
		  <footer class="footer span11">
			<?php print render($page['footer']); ?>
		  </footer>
		</div>
  </div>
