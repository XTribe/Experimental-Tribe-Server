<?php

global $theme_key;

include_once(dirname(__FILE__) . '/includes/etslook.inc');
include_once(dirname(__FILE__) . '/includes/modules/theme.inc');
include_once(dirname(__FILE__) . '/includes/modules/pager.inc');
include_once(dirname(__FILE__) . '/includes/modules/form.inc');

$modules = module_list();

foreach ($modules as $module) {
  if (is_file(drupal_get_path('theme', $theme_key) . '/includes/modules/' . str_replace('_', '-', $module) . '.inc')) {
    include_once(drupal_get_path('theme', $theme_key) . '/includes/modules/' . str_replace('_', '-', $module) . '.inc');
  }    
}

/**
 * Preprocess variables for html.tpl.php
 *
 * @see system_elements()
 * @see html.tpl.php
 */
function etslook_preprocess_html(&$vars) {

  $js = preg_split( '/\r\n|\r|\n/', etslook_theme_get_setting('etslook_js_files'));
  foreach($js as $file) {
    drupal_add_js($file);
  }
  
  $css = preg_split( '/\r\n|\r|\n/', etslook_theme_get_setting('etslook_css_files'));
  foreach($css as $file) {
    drupal_add_css($file, array('type' => 'external'));
  }

}

function etslook_breadcrumb($vars) {
  $breadcrumb = $vars['breadcrumb'];

  if (!empty($breadcrumb)) {
    $breadcrumbs = '<ul class="breadcrumb">';
    
    $count = count($breadcrumb) - 1;
    foreach($breadcrumb as $key => $value) {
      if($count != $key) {
        $breadcrumbs .= '<li>'.$value.'<span class="divider">/</span></li>';
      }else{
        $breadcrumbs .= '<li>'.$value.'</li>';
      }
    }
    $breadcrumbs .= '</ul>';
    
    return $breadcrumbs;
  }
}

/**
 * Preprocess variables for node.tpl.php
 *
 * @see node.tpl.php
 */
function etslook_preprocess_node(&$vars) {
  //if($vars['teaser'])
   //$vars['classes_array'][] = 'row';
}

/**
 * Preprocess variables for block.tpl.php
 *
 * @see block.tpl.php
 */
function etslook_preprocess_block(&$vars) {

  // Flag the first block in each region.
  if ($vars['block_id'] == 1) {
    $vars['classes_array'][] = 'first';
  }

  //$vars['classes_array'][] = 'row';
}

/**
 * Preprocess variables for page.tpl.php
 *
 * @see page.tpl.php
 */
function etslook_preprocess_page(&$variables) {
  // Add information about the number of sidebars.
  if (!empty($variables['page']['sidebar_first']) && !empty($variables['page']['sidebar_second'])) {
    $variables['columns'] = 3;
  }
  elseif (!empty($variables['page']['sidebar_first'])) {
    $variables['columns'] = 2;
  }
  elseif (!empty($variables['page']['sidebar_second'])) {
    $variables['columns'] = 2;
  }
  else {
    $variables['columns'] = 1;
  }
 //print_r($variables); 
 //$variables['exp_active'] = (bool)ets_get_node_field($variables['node'], 'active');

  // Our custom search because its cool :)
  //$variables['search'] = drupal_get_form('_etslook_search_form');
  
  // Add user menu
  //$variables['user_menu'] = menu_navigation_links('user-menu');
}

/*
function _etslook_search_form($form, &$form_state) {
}

function etslook_preprocess_form_element(&$vars) {
}
*/

/**
 * Preprocess variables for region.tpl.php
 *
 * @see region.tpl.php
 */
function etslook_preprocess_region(&$vars) {  
  if($vars['region'] == "sidebar_first" || $vars['region'] == "sidebar_second")
    $vars['classes_array'][] = 'span2';
  
  if($vars['region'] == "sidebar_second")
    $vars['classes_array'][] = 'span2';
    
  if($vars['region'] == "highlight")
    $vars['classes_array'][] = 'span11';  
}

/**
 * Returns the correct span class for a region
 */
function _etslook_content_span($columns = 1) {
  switch($columns) {
    case 1:
      $class = 'span11';
      break;
    case 2:
      $class = 'span9';
      break;
    case 3:
      $class = 'span4';
      break;
  }
  
  return $class;
}

/**
 * Return a link to initiate a Facebook Connect login or association.
 *
 * @param $link
 *   An array of properties to be used to generate a login link. Note that all
 *   provided properties are required for the Facebook login to succeed and
 *   must not be changed. If $link is FALSE, Facebook OAuth is not yet
 *   configured.
 * @see fboauth_link_properties()
 */
function etslook_fboauth_action__connect($variables) {
  $action = $variables['action'];
  $link = $variables['properties'];
  $url = url($link['href'], array('query' => $link['query']));
  $link['attributes']['class'] = isset($link['attributes']['class']) ? $link['attributes']['class'] : 'facebook-action-connect';
  $attributes = isset($link['attributes']) ? drupal_attributes($link['attributes']) : '';
  $title = isset($link['title']) ? check_plain($link['title']) : '';
  $src = ($GLOBALS['is_https'] ? 'https' : 'http') . '://www.facebook.com/images/fbconnect/login-buttons/connect_light_medium_short.gif?aa=3';
  //$src = "/sites/all/themes/etslook/fb_login.png";
  //$fburl = '<a class="fb-connect" ' . $attributes . ' href="' . $url . '"><img src="' . $src . '" alt="' . $title . '" /></a>';
  $src = "/sites/all/themes/kreyonTheme/images/fb_logo.png";
  $fburl = '<a class="fb-connect" ' . $attributes . ' href="' . $url . '"><img src="' . $src . '" alt="' . $title . '" />&nbsp;&nbsp;Connect</a>';
  
  return $fburl;
}

function etslook_lt_unified_login_page($variables) {

  $login_form = $variables['login_form'];
  $register_form = $variables['register_form'];
  $active_form = $variables['active_form'];
  $output = '';

  $output .= '<div class="toboggan-unified ' . $active_form . '">';

  $fb_connect_link = theme("fboauth_action__connect", array('properties' => fboauth_action_link_properties("connect")));

  // Create the initial message and links that people can click on.
  $output .= '<div id="login-links">';
  $output .= l(t('I want to create an account'), 'user/register', array('attributes' => array('class' => array('btn-x-green'), 'id' => 'register-link')));
  $output .= $fb_connect_link;
  $output .= '</div>';

  // Add the login and registration forms in.
  $output .= '<div id="login-form">' . $login_form . '</div>';
  $output .= '<div id="register-form">' . $register_form . '</div>';

  $output .= '</div>';

  return $output;
}


/*
function etslook_fbconnect_login_button($variables) {
  $op = $variables['op'];
  $user_profile = $variables['user_profile'];
  $text = $variables['text'];
  $attr = $variables['attr'];
  if ($op == 'login') {
    $url = url('fbconnect/register/create');
    $title = $user_profile['name'];
    $desc = "";
    $link = l('<span class="fb_button_text">' . $text . '</span>', 'fbconnect/register/create', array('html' => TRUE, 'attributes' => array('class' => array('fb_button fb_button_' . $attr['size']))));
    $button = '<button onclick="location.href=\'' . $url . '\'" id="fblogin" type="button">Log in</button>';
    #return 'as <span class="name">' . $title . '</span>' . $desc . $link;
    return $link;
  }
  else {
    $attr['data-scope'] = "email";
    $button = '<fb:login-button ' . drupal_attributes($attr) . '>' . $text . '</fb:login-button>';
    return $button;
  }
}
*/



